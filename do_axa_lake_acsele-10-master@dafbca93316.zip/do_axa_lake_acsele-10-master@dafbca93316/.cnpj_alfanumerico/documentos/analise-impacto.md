# Plano de Implementação - CNPJ Alfanumérico
## DO_AXA_LAKE_ACSELE-10

---

**Versão:** 1.0  
**Data:** Janeiro/2026  
**Projeto:** DO_AXA_LAKE_ACSELE-10  
**Responsável:** Equipe de Desenvolvimento  

---

## 📑 Índice

1. [Resumo Executivo](#resumo-executivo)  
2. [Análise do Sistema Atual](#análise-do-sistema-atual)  
3. [Impactos Identificados](#impactos-identificados)  
4. [Packages SSIS Impactados](#packages-ssis-impactados)  
5. [Plano de Implementação](#plano-de-implementação)  
6. [Alterações Detalhadas](#alterações-detalhadas)  
7. [Scripts de Migração](#scripts-de-migração)  
8. [Testes e Validação](#testes-e-validação)  
9. [Cronograma](#cronograma)  
10. [Riscos e Mitigações](#riscos-e-mitigações)  
11. [Anexos](#anexos)  

---

## 📌 Resumo Executivo

### Objetivo
Analisar os packages SSIS do projeto **DO_AXA_LAKE_ACSELE-10** para identificar ocorrências de campos relacionados a CNPJ/CPF e avaliar a necessidade de adequação ao **novo formato alfanumérico de CNPJ** conforme IN RFB nº 2.119/2022 e IN RFB nº 2.229/2024.

### Resultado da Análise
**Após análise completa de todos os 21 packages SSIS do projeto, não foram identificadas referências diretas a campos de CNPJ, CPF, NUMID, CGC, NR_DOCTO ou NR_CPF_CNPJ nos Data Flows, queries SQL ou transformações.**

### Estrutura do Novo CNPJ
| Bloco | Posição | Conteúdo      | Tipo                        |
|-------|---------|---------------|-----------------------------|
| Raiz  | 1–8     | Alfanumérica  | Letras maiúsculas e números |
| Ordem | 9–12    | Alfanumérica  | Letras maiúsculas e números |
| DV    | 13–14   | Numérica      | Apenas números              |

**Formato:** `SS.SSS.SSS/SSSS-NN`

### Conclusão Preliminar
Os packages deste projeto são focados em **extração e carga de dados de garantias** (tabelas IOGAR*) e **metadados** do sistema ACSELE, não manipulando diretamente campos de documentos de identificação (CNPJ/CPF). Recomenda-se verificação adicional nas:
- Tabelas de origem no Oracle (ACSELE_AXA)
- Stored Procedures referenciadas
- Tabelas de destino no SQL Server (db_Lake)

---

## 🧭 Análise do Sistema Atual

### Estrutura do Projeto
| Característica | Valor |
|----------------|-------|
| Nome do Projeto | DO_AXA_LAKE_ACSELE-10 |
| Total de Packages | 21 arquivos .dtsx |
| Versão SSIS | SQL Server 2019 (LastModifiedProductVersion: 15.0.2000.180) |
| Tipo de Carga | ETL Oracle → SQL Server |

### Connection Managers
| Connection Manager | Tipo | Destino |
|--------------------|------|---------|
| OLEDB_ACSELE | OLE DB | Oracle - acsele-prod-scan/ACSELPRD_RAC |
| OLEDB_LAKE | OLE DB | SQL Server - db_Lake |
| OLEDB_LAKE_CONFIG | OLE DB | SQL Server - db_Lake_Configuracao |
| OLEDB_LAKE_STAGING | OLE DB | SQL Server - db_Lake_Staging |

### Packages SSIS Identificados

| # | Package | Tabela Origem | Descrição |
|---|---------|---------------|-----------|
| 01 | DO_LAKE_ACSELE-10-01-IOGAREFMT.dtsx | IOGAREFMT | Garantia Ref. Mato Grosso |
| 02 | DO_LAKE_ACSELE-10-02-IOGAREFPB.dtsx | IOGAREFPB | Garantia Ref. Paraíba |
| 03 | DO_LAKE_ACSELE-10-03-IOGAREFPE.dtsx | IOGAREFPE | Garantia Ref. Pernambuco |
| 04 | DO_LAKE_ACSELE-10-04-IOGAREFPR.dtsx | IOGAREFPR | Garantia Ref. Paraná |
| 05 | DO_LAKE_ACSELE-10-05-IOGAREFRJ.dtsx | IOGAREFRJ | Garantia Ref. Rio de Janeiro |
| 06 | DO_LAKE_ACSELE-10-06-IOGAREFRS.dtsx | IOGAREFRS | Garantia Ref. Rio Grande do Sul |
| 07 | DO_LAKE_ACSELE-10-07-IOGAREFSC.dtsx | IOGAREFSC | Garantia Ref. Santa Catarina |
| 08 | DO_LAKE_ACSELE-10-08-IOGAREFSP.dtsx | IOGAREFSP | Garantia Ref. São Paulo |
| 09 | DO_LAKE_ACSELE-10-09-IOGAREFUNIAO.dtsx | IOGAREFUNIAO | Garantia Ref. União |
| 10 | DO_LAKE_ACSELE-10-10-IOGAREXECOBRASIMOB.dtsx | IOGAREXECOBRASIMOB | Garantia Execução Obras Imob. |
| 11 | DO_LAKE_ACSELE-10-11-IOGAREXECUTANTECONCES.dtsx | IOGAREXECUTANTECONCES | Garantia Executante Concessão |
| 12 | DO_LAKE_ACSELE-10-12-IOGARJUDICIALTRAB.dtsx | IOGARJUDICIALTRAB | Garantia Judicial Trabalhista |
| 13 | DO_LAKE_ACSELE-10-13-IOGARLICITANTEOUTAGREG.dtsx | IOGARLICITANTEOUTAGREG | Garantia Licitante/Agregados |
| 14 | DO_LAKE_ACSELE-10-14-IOGARMANUTCORRET.dtsx | IOGARMANUTCORRET | Garantia Manutenção Corretiva |
| 15 | DO_LAKE_ACSELE-10-15-IOGARPARCADMFIS.dtsx | IOGARPARCADMFIS | Garantia Parceria Adm. Fiscal |
| 16 | DO_LAKE_ACSELE-10-16-IOGARPERMIMOB.dtsx | IOGARPERMIMOB | Garantia Permuta Imobiliária |
| 17 | DO_LAKE_ACSELE-10-17-IOGARRETPAG.dtsx | IOGARRETPAG | Garantia Retenção Pagamento |
| 18 | DO_LAKE_ACSELE-10-18-IOGARSGPE.dtsx | IOGARSGPE | Garantia SGPE |
| 19 | DO_LAKE_ACSELE-10-19-ASSESSORIA.dtsx | ASSESSORIA | Assessoria |
| 20 | DO_LAKE_ACSELE-10-20-IOGAREMPREENDIMOB.dtsx | IOGAREMPREENDIMOB | Garantia Empreendimento Imob. |
| 21 | Config_ORACLE.dtsx | all_tab_cols / all_constraints | Configuração/Metadados Oracle |

### Estrutura Padrão dos Packages

Cada package (exceto Config_ORACLE) segue a seguinte estrutura:

```
Package
├── Connection Managers
│   ├── OLEDB_ACSELE (Oracle)
│   ├── OLEDB_LAKE (SQL Server)
│   ├── OLEDB_LAKE_CONFIG (SQL Server Config)
│   └── OLEDB_LAKE_STAGING (SQL Server Staging)
├── Variables
│   ├── Str_NomeTabela (nome da tabela)
│   ├── Str_Sql (query SELECT)
│   ├── Str_SQL_SELECT_Carga_Full (query carga full)
│   └── ... (variáveis de controle)
├── Control Flow
│   ├── Sequence Container "Carga FULL"
│   │   ├── Execute SQL Task "Atualiza Flag Incremental"
│   │   ├── Data Flow Task "Carga - FULL"
│   │   │   ├── OLE DB Source (Oracle)
│   │   │   ├── Row Count
│   │   │   └── OLE DB Destination (SQL Server)
│   │   └── Execute SQL Task "Log"
│   └── Script Task (Obtenção de variáveis via WCF)
└── Event Handlers
```

### Tipos de Dados Utilizados

| Tipo SSIS | Descrição | Colunas Típicas |
|-----------|-----------|-----------------|
| numeric (precision=19) | Numérico de alta precisão | PK, STATIC, STATUS |
| str (codePage=1252) | String ANSI | ACTION, GARCLAUSTXT*VALUE |
| text (codePage=1252) | Texto longo | GARCLAUSTXT*INPUT, TXTGAROBSINPUT |
| dbTimeStamp | Data/Hora | DT_ATUALIZACAO_ORIGEM, DT_CARGA |

---

## ⚠️ Impactos Identificados

### Resultado da Busca por Campos de Identificação

**Campos Pesquisados:**
- `CNPJ`
- `CPF`
- `NUMID`
- `CGC`
- `NR_DOCTO`
- `NR_CPF_CNPJ`

**Resultado:** ❌ **Nenhuma ocorrência direta encontrada** nos packages SSIS.

### Classificação por Criticidade

| Criticidade | Quantidade | Descrição |
|-------------|------------|-----------|
| **Crítica** | 0 | Não identificadas |
| **Moderada** | 0 | Não identificadas |
| **Baixa** | 0 | Não identificadas |

### Análise Detalhada dos Componentes

#### Queries SQL Analisadas (Exemplo - Package IOGAREFMT)

```sql
-- Carga Incremental
SELECT 
    LP.PK, A.STATIC, A.STATUS,
    A.TXTGAROBSINPUT, A.TXTGAROBSVALUE,
    A.GARCLAUSTXTIINPUT, A.GARCLAUSTXTIVALUE,
    -- ... demais cláusulas de garantia (I até IX)
    LP.dt_cdc_last_update_date AS DT_ATUALIZACAO_ORIGEM,
    LP.cd_cdc_type AS ACTION
FROM ACSELE_AXA_CDC.DO_IOGAREFMT LP
LEFT JOIN ACSELE_AXA.IOGAREFMT A ON A.PK = LP.PK
WHERE cd_cdc_state = '0' AND rownum <= -1

-- Carga Full
SELECT 
    A.PK, A.STATIC, A.STATUS,
    A.TXTGAROBSINPUT, A.TXTGAROBSVALUE,
    A.GARCLAUSTXTIINPUT, A.GARCLAUSTXTIVALUE,
    -- ... demais cláusulas de garantia (I até IX)
    systimestamp as DT_ATUALIZACAO_ORIGEM,
    CAST('I' AS VARCHAR(1)) as ACTION,
    systimestamp as DT_CARGA
FROM ACSELE_AXA.IOGAREFMT A
```

**Observação:** As queries extraem campos relacionados a **cláusulas contratuais de garantia** (GARCLAUSTXT*), não campos de identificação pessoal/empresarial.

#### Colunas nos Data Flows

| Coluna | Tipo | Presença em CNPJ |
|--------|------|------------------|
| PK | numeric(19) | ❌ Identificador interno |
| STATIC | numeric(19) | ❌ Flag de status |
| STATUS | numeric(19) | ❌ Status da garantia |
| GARCLAUSTXT*INPUT | text | ❌ Texto de cláusula |
| GARCLAUSTXT*VALUE | str(4000) | ❌ Valor de cláusula |
| DT_ATUALIZACAO_ORIGEM | dbTimeStamp | ❌ Data de atualização |
| ACTION | str(1) | ❌ Tipo de ação CDC |
| DT_CARGA | dbTimeStamp | ❌ Data de carga |

---

## 🔍 Packages SSIS Impactados

### Resumo de Impacto

| Package | Data Flow Tasks | Control Flow Tasks | Variáveis | Script Tasks | **Impacto CNPJ** |
|---------|-----------------|--------------------|-----------|--------------|--------------------|
| DO_LAKE_ACSELE-10-01-IOGAREFMT.dtsx | 2 | 6 | 30+ | 1 | ✅ Nenhum |
| DO_LAKE_ACSELE-10-02-IOGAREFPB.dtsx | 2 | 6 | 30+ | 1 | ✅ Nenhum |
| DO_LAKE_ACSELE-10-03-IOGAREFPE.dtsx | 2 | 6 | 30+ | 1 | ✅ Nenhum |
| DO_LAKE_ACSELE-10-04-IOGAREFPR.dtsx | 2 | 6 | 30+ | 1 | ✅ Nenhum |
| DO_LAKE_ACSELE-10-05-IOGAREFRJ.dtsx | 2 | 6 | 30+ | 1 | ✅ Nenhum |
| DO_LAKE_ACSELE-10-06-IOGAREFRS.dtsx | 2 | 6 | 30+ | 1 | ✅ Nenhum |
| DO_LAKE_ACSELE-10-07-IOGAREFSC.dtsx | 2 | 6 | 30+ | 1 | ✅ Nenhum |
| DO_LAKE_ACSELE-10-08-IOGAREFSP.dtsx | 2 | 6 | 30+ | 1 | ✅ Nenhum |
| DO_LAKE_ACSELE-10-09-IOGAREFUNIAO.dtsx | 2 | 6 | 30+ | 1 | ✅ Nenhum |
| DO_LAKE_ACSELE-10-10-IOGAREXECOBRASIMOB.dtsx | 2 | 6 | 30+ | 1 | ✅ Nenhum |
| DO_LAKE_ACSELE-10-11-IOGAREXECUTANTECONCES.dtsx | 2 | 6 | 30+ | 1 | ✅ Nenhum |
| DO_LAKE_ACSELE-10-12-IOGARJUDICIALTRAB.dtsx | 2 | 6 | 30+ | 1 | ✅ Nenhum |
| DO_LAKE_ACSELE-10-13-IOGARLICITANTEOUTAGREG.dtsx | 2 | 6 | 30+ | 1 | ✅ Nenhum |
| DO_LAKE_ACSELE-10-14-IOGARMANUTCORRET.dtsx | 2 | 6 | 30+ | 1 | ✅ Nenhum |
| DO_LAKE_ACSELE-10-15-IOGARPARCADMFIS.dtsx | 2 | 6 | 30+ | 1 | ✅ Nenhum |
| DO_LAKE_ACSELE-10-16-IOGARPERMIMOB.dtsx | 2 | 6 | 30+ | 1 | ✅ Nenhum |
| DO_LAKE_ACSELE-10-17-IOGARRETPAG.dtsx | 2 | 6 | 30+ | 1 | ✅ Nenhum |
| DO_LAKE_ACSELE-10-18-IOGARSGPE.dtsx | 2 | 6 | 30+ | 1 | ✅ Nenhum |
| DO_LAKE_ACSELE-10-19-ASSESSORIA.dtsx | 2 | 6 | 30+ | 1 | ✅ Nenhum |
| DO_LAKE_ACSELE-10-20-IOGAREMPREENDIMOB.dtsx | 2 | 6 | 30+ | 1 | ✅ Nenhum |
| Config_ORACLE.dtsx | 2 | 2 | 2 | 0 | ✅ Nenhum |

---

## 🔍 Arquivos Críticos Identificados

| Categoria                | Quantidade | Status CNPJ |
|--------------------------|------------|-------------|
| Packages SSIS (.dtsx)    | 21         | ✅ Sem ocorrências |
| Data Flow Tasks          | 42         | ✅ Sem ocorrências |
| Script Tasks/Components  | 20         | ✅ Sem ocorrências diretas |
| Connection Managers      | 4          | ✅ Sem ocorrências |
| Stored Procedures (ref.) | ~5         | ⚠️ Verificar no banco |
| Variáveis                | ~600       | ✅ Sem ocorrências |

---

## 📂 Alterações Detalhadas

### Alterações Necessárias nos Packages SSIS

**Nenhuma alteração é necessária nos packages SSIS deste projeto**, pois:

1. As tabelas de origem (IOGAR*) não contêm campos de CNPJ/CPF diretamente nas colunas migradas
2. Os Data Flows transferem apenas dados de cláusulas contratuais de garantia
3. Não há transformações de dados que manipulem identificadores de pessoa/empresa

### Pontos de Atenção - Verificação Adicional Recomendada

#### 1. Campos TEXT/CLOB (GARCLAUSTXT*VALUE)
Os campos do tipo TEXT podem conter CNPJ/CPF como parte do conteúdo textual não estruturado.

```json
{
  "verificacao": "GARCLAUSTXT*VALUE",
  "tipo": "text/str(4000)",
  "acao": "Verificar se textos de cláusulas contêm CNPJ incorporado",
  "criticidade": "Baixa",
  "motivo": "Dados não estruturados - não afetam validação"
}
```

#### 2. Stored Procedures Referenciadas

| Procedure | Package | Verificação |
|-----------|---------|-------------|
| [ACSELE].[INS_OPENITEM] | Todos | ⚠️ Verificar no banco |
| [Config].[DO_USP_UPDATE_TRIGGER] | Todos | ⚠️ Verificar no banco |
| [Config].[USP_UPD_Processo] | Todos | ⚠️ Verificar no banco |
| [Config].[DO_USP_CONTROLE_CARGA_FULL] | Todos | ⚠️ Verificar no banco |

#### 3. Tabelas de Origem Oracle (ACSELE_AXA)

Tabelas que devem ser verificadas no banco de dados Oracle:

- ACSELE_AXA.IOGAREFMT (e demais IOGAREF*)
- ACSELE_AXA.ASSESSORIA
- ACSELE_AXA_CDC.DO_IOGAREFMT (e demais DO_IOGAR*)

---

## 🚀 Plano de Implementação

### Fase 1 - Validação (Concluída)
✅ Análise de todos os packages SSIS  
✅ Busca por campos CNPJ/CPF/NUMID/CGC/NR_DOCTO/NR_CPF_CNPJ  
✅ Verificação de tipos de dados  
✅ Análise de queries SQL  

### Fase 2 - Verificação Complementar (Recomendada)

1. **Verificar tabelas de origem no Oracle**
   ```sql
   -- Executar no Oracle
   SELECT COLUMN_NAME, DATA_TYPE, DATA_LENGTH 
   FROM ALL_TAB_COLUMNS 
   WHERE TABLE_NAME LIKE 'IOGAR%' 
     AND (COLUMN_NAME LIKE '%CNPJ%' 
          OR COLUMN_NAME LIKE '%CPF%' 
          OR COLUMN_NAME LIKE '%NUMID%'
          OR COLUMN_NAME LIKE '%CGC%'
          OR COLUMN_NAME LIKE '%NR_DOCTO%')
   ORDER BY TABLE_NAME, COLUMN_ID;
   ```

2. **Verificar stored procedures**
   ```sql
   -- Executar no SQL Server
   SELECT OBJECT_NAME(object_id) AS ProcName, definition
   FROM sys.sql_modules
   WHERE definition LIKE '%CNPJ%' OR definition LIKE '%CPF%'
   ORDER BY OBJECT_NAME(object_id);
   ```

3. **Verificar tabelas de destino no SQL Server**
   ```sql
   -- Executar no SQL Server
   SELECT TABLE_NAME, COLUMN_NAME, DATA_TYPE, CHARACTER_MAXIMUM_LENGTH
   FROM INFORMATION_SCHEMA.COLUMNS
   WHERE TABLE_SCHEMA = 'ACSELE'
     AND (COLUMN_NAME LIKE '%CNPJ%' 
          OR COLUMN_NAME LIKE '%CPF%'
          OR COLUMN_NAME LIKE '%NUMID%')
   ORDER BY TABLE_NAME, ORDINAL_POSITION;
   ```

### Fase 3 - Implementação (Se Aplicável)

Caso sejam encontradas ocorrências nas verificações complementares:

1. Criar Script Component para validação de CNPJ alfanumérico
2. Ajustar Data Conversion Transformations (se tipos numéricos)
3. Atualizar queries SQL (se necessário)
4. Modificar Stored Procedures (no banco de dados)

---

## 🛠 Scripts de Migração

### Scripts de Verificação

**Script 1: Verificar colunas de CNPJ no Oracle**
```sql
-- Oracle - ACSELE_AXA
SELECT 
    TABLE_NAME,
    COLUMN_NAME,
    DATA_TYPE,
    DATA_LENGTH,
    DATA_PRECISION,
    NULLABLE
FROM ALL_TAB_COLUMNS
WHERE OWNER = 'ACSELE_AXA'
  AND (
    UPPER(COLUMN_NAME) LIKE '%CNPJ%'
    OR UPPER(COLUMN_NAME) LIKE '%CPF%'
    OR UPPER(COLUMN_NAME) LIKE '%NUMID%'
    OR UPPER(COLUMN_NAME) LIKE '%CGC%'
    OR UPPER(COLUMN_NAME) LIKE '%NR_DOCTO%'
    OR UPPER(COLUMN_NAME) LIKE '%NR_CPF_CNPJ%'
  )
ORDER BY TABLE_NAME, COLUMN_NAME;
```

**Script 2: Verificar colunas no SQL Server (Lake)**
```sql
-- SQL Server - db_Lake
SELECT 
    t.TABLE_SCHEMA,
    t.TABLE_NAME,
    c.COLUMN_NAME,
    c.DATA_TYPE,
    c.CHARACTER_MAXIMUM_LENGTH,
    c.NUMERIC_PRECISION,
    c.IS_NULLABLE
FROM INFORMATION_SCHEMA.TABLES t
INNER JOIN INFORMATION_SCHEMA.COLUMNS c 
    ON t.TABLE_NAME = c.TABLE_NAME 
    AND t.TABLE_SCHEMA = c.TABLE_SCHEMA
WHERE t.TABLE_SCHEMA IN ('ACSELE', 'ACSELE_IO')
  AND (
    UPPER(c.COLUMN_NAME) LIKE '%CNPJ%'
    OR UPPER(c.COLUMN_NAME) LIKE '%CPF%'
    OR UPPER(c.COLUMN_NAME) LIKE '%NUMID%'
    OR UPPER(c.COLUMN_NAME) LIKE '%CGC%'
    OR UPPER(c.COLUMN_NAME) LIKE '%NR_DOCTO%'
    OR UPPER(c.COLUMN_NAME) LIKE '%NR_CPF_CNPJ%'
  )
ORDER BY t.TABLE_SCHEMA, t.TABLE_NAME, c.COLUMN_NAME;
```

### Script de Validação de CNPJ Alfanumérico (Referência)

Caso seja necessário implementar validação em Script Component:

```csharp
/// <summary>
/// Valida CNPJ no formato alfanumérico (IN RFB 2.119/2022)
/// Estrutura: 8 caracteres raiz + 4 ordem + 2 dígitos verificadores
/// </summary>
public static bool ValidarCnpjAlfanumerico(string cnpj)
{
    if (string.IsNullOrEmpty(cnpj))
        return false;
    
    // Remove formatação
    cnpj = cnpj.Replace(".", "").Replace("/", "").Replace("-", "").ToUpper();
    
    if (cnpj.Length != 14)
        return false;
    
    // Regex para validar estrutura
    // Raiz (8 alfanuméricos) + Ordem (4 alfanuméricos) + DV (2 numéricos)
    var regex = new System.Text.RegularExpressions.Regex(@"^[A-Z0-9]{12}\d{2}$");
    if (!regex.IsMatch(cnpj))
        return false;
    
    // Calcular primeiro dígito verificador
    int[] pesos1 = { 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2 };
    int soma = 0;
    for (int i = 0; i < 12; i++)
    {
        // Valor ASCII - 48 (conforme especificação RFB)
        int valor = (int)cnpj[i] - 48;
        soma += valor * pesos1[i];
    }
    int resto = soma % 11;
    int dv1 = resto < 2 ? 0 : 11 - resto;
    
    // Verificar primeiro DV
    if (dv1 != (cnpj[12] - '0'))
        return false;
    
    // Calcular segundo dígito verificador
    int[] pesos2 = { 6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2 };
    soma = 0;
    for (int i = 0; i < 13; i++)
    {
        int valor = (int)cnpj[i] - 48;
        soma += valor * pesos2[i];
    }
    resto = soma % 11;
    int dv2 = resto < 2 ? 0 : 11 - resto;
    
    // Verificar segundo DV
    return dv2 == (cnpj[13] - '0');
}
```

---

## ✅ Testes e Validação

### Cenários de Teste (Quando Aplicável)

| # | Cenário | CNPJ Teste | Resultado Esperado |
|---|---------|------------|-------------------|
| 1 | CNPJ numérico válido | 11222333000181 | Válido |
| 2 | CNPJ alfanumérico válido | 12ABC34501DE35 | Válido (com DV correto) |
| 3 | CNPJ com formatação | 12.ABC.345/01DE-35 | Válido (após limpeza) |
| 4 | CNPJ inválido (DV errado) | 12ABC34501DE99 | Inválido |
| 5 | CNPJ vazio | "" | Inválido |
| 6 | CNPJ com caracteres especiais | 12@BC34501DE35 | Inválido |

### Checklist de Validação

- [ ] Verificar tabelas de origem no Oracle
- [ ] Verificar stored procedures no SQL Server
- [ ] Verificar tabelas de destino no SQL Server
- [ ] Testar packages SSIS após alterações (se aplicável)
- [ ] Validar retrocompatibilidade com CNPJ numérico existente
- [ ] Testar carga incremental
- [ ] Testar carga full

---

## 🛡 Riscos e Mitigações

| # | Risco | Probabilidade | Impacto | Mitigação |
|---|-------|---------------|---------|-----------|
| 1 | Campos de CNPJ em outras tabelas não analisadas | Média | Alto | Executar scripts de verificação nas demais tabelas |
| 2 | CNPJ incorporado em campos TEXT | Alta | Baixo | Não afeta validações estruturadas; monitorar relatórios |
| 3 | Stored procedures com validação de CNPJ numérico | Média | Médio | Verificar e atualizar procedures no banco |
| 4 | Sistemas externos que consomem dados do Lake | Média | Alto | Mapear integrações e notificar equipes responsáveis |
| 5 | Performance após conversão de tipos | Baixa | Médio | Testar em ambiente de homologação |

---

## 📎 Anexos

### A. Normativas de Referência
- **IN RFB nº 2.119/2022** - Institui o CNPJ alfanumérico
- **IN RFB nº 2.229/2024** - Atualizações sobre CNPJ alfanumérico
- **Anexo XV – CNPJ Alfanumérico** - Especificações técnicas

### B. Tipos de Dados SSIS

| Tipo SSIS | Tipo .NET | Tipo SQL Server | Suporta Alfanumérico |
|-----------|-----------|-----------------|----------------------|
| DT_STR | String | VARCHAR | ✅ Sim |
| DT_WSTR | String | NVARCHAR | ✅ Sim |
| DT_I4 | Int32 | INT | ❌ Não |
| DT_I8 | Int64 | BIGINT | ❌ Não |
| DT_NUMERIC | Decimal | NUMERIC | ❌ Não |

### C. Estrutura de Diretórios do Projeto

```
DO_AXA_LAKE_ACSELE-10/
├── .cnpj_alfanumerico/
│   ├── contexto/
│   │   └── cnpj/
│   │       ├── cnpj-alfanumerico-diretrizes.md
│   │       └── cnpj-identificacao-ocorrencias.md
│   └── documentos/
│       └── analise-impacto.md (este documento)
├── Config_ORACLE.dtsx
├── DO_LAKE_ACSELE-10-01-IOGAREFMT.dtsx
├── DO_LAKE_ACSELE-10-02-IOGAREFPB.dtsx
├── ... (demais packages)
├── DO_LAKE_ACSELE-10-20-IOGAREMPREENDIMOB.dtsx
├── DO_AXA_LAKE_ACSELE-10.database
├── DO_AXA_LAKE_ACSELE-10.dtproj
├── DO_AXA_LAKE_ACSELE-10.sln
└── Project.params
```

---

## 📋 Histórico de Revisões

| Versão | Data | Autor | Descrição |
|--------|------|-------|-----------|
| 1.0 | Janeiro/2026 | Equipe de Desenvolvimento | Versão inicial - Análise completa dos packages |

---

**Documento gerado automaticamente pela análise do projeto DO_AXA_LAKE_ACSELE-10**

**Conclusão Final:** Os packages SSIS deste projeto **não requerem alterações** para adequação ao CNPJ alfanumérico, pois não manipulam campos de identificação diretamente. Recomenda-se verificação complementar nas camadas de banco de dados (Oracle origem e SQL Server destino) e stored procedures referenciadas.
